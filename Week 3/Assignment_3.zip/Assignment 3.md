
---

_You are currently looking at **version 1.5** of this notebook. To download notebooks and datafiles, as well as get help on Jupyter notebooks in the Coursera platform, visit the [Jupyter Notebook FAQ](https://www.coursera.org/learn/python-data-analysis/resources/0dhYG) course resource._

---

# Assignment 3 - More Pandas
This assignment requires more individual learning then the last one did - you are encouraged to check out the [pandas documentation](http://pandas.pydata.org/pandas-docs/stable/) to find functions or methods you might not have used yet, or ask questions on [Stack Overflow](http://stackoverflow.com/) and tag them as pandas and python related. And of course, the discussion forums are open for interaction with your peers and the course staff.

### Question 1 (20%)
Load the energy data from the file `Energy Indicators.xls`, which is a list of indicators of [energy supply and renewable electricity production](Energy%20Indicators.xls) from the [United Nations](http://unstats.un.org/unsd/environment/excel_file_tables/2013/Energy%20Indicators.xls) for the year 2013, and should be put into a DataFrame with the variable name of **energy**.

Keep in mind that this is an Excel file, and not a comma separated values file. Also, make sure to exclude the footer and header information from the datafile. The first two columns are unneccessary, so you should get rid of them, and you should change the column labels so that the columns are:

`['Country', 'Energy Supply', 'Energy Supply per Capita', '% Renewable']`

Convert `Energy Supply` to gigajoules (there are 1,000,000 gigajoules in a petajoule). For all countries which have missing data (e.g. data with "...") make sure this is reflected as `np.NaN` values.

Rename the following list of countries (for use in later questions):

```"Republic of Korea": "South Korea",
"United States of America": "United States",
"United Kingdom of Great Britain and Northern Ireland": "United Kingdom",
"China, Hong Kong Special Administrative Region": "Hong Kong"```

There are also several countries with numbers and/or parenthesis in their name. Be sure to remove these, 

e.g. 

`'Bolivia (Plurinational State of)'` should be `'Bolivia'`, 

`'Switzerland17'` should be `'Switzerland'`.

<br>

Next, load the GDP data from the file `world_bank.csv`, which is a csv containing countries' GDP from 1960 to 2015 from [World Bank](http://data.worldbank.org/indicator/NY.GDP.MKTP.CD). Call this DataFrame **GDP**. 

Make sure to skip the header, and rename the following list of countries:

```"Korea, Rep.": "South Korea", 
"Iran, Islamic Rep.": "Iran",
"Hong Kong SAR, China": "Hong Kong"```

<br>

Finally, load the [Sciamgo Journal and Country Rank data for Energy Engineering and Power Technology](http://www.scimagojr.com/countryrank.php?category=2102) from the file `scimagojr-3.xlsx`, which ranks countries based on their journal contributions in the aforementioned area. Call this DataFrame **ScimEn**.

Join the three datasets: GDP, Energy, and ScimEn into a new dataset (using the intersection of country names). Use only the last 10 years (2006-2015) of GDP data and only the top 15 countries by Scimagojr 'Rank' (Rank 1 through 15). 

The index of this DataFrame should be the name of the country, and the columns should be ['Rank', 'Documents', 'Citable documents', 'Citations', 'Self-citations',
       'Citations per document', 'H index', 'Energy Supply',
       'Energy Supply per Capita', '% Renewable', '2006', '2007', '2008',
       '2009', '2010', '2011', '2012', '2013', '2014', '2015'].

*This function should return a DataFrame with 20 columns and 15 entries.*


```python
def answer_one():
    import pandas as pd
    import numpy as np
    energy = pd.read_excel('Energy Indicators.xls',
                           header = None, 
                           usecols=range(2,6),
                           names = ['Country', 'Energy Supply', 'Energy Supply per Capita', '% Renewable'])
    energy = energy[18:245]

    # replacing missing values
    energy.replace(to_replace = '...', value = np.NaN, inplace = True)

    # converting to gigajoules
    energy['Energy Supply'] = energy['Energy Supply']*1000000

    # Removing Numbered Countries
    energy['Country'] = energy['Country'].str.replace('\d+', '')

    # Removing Countries with Parenthises in name
    energy['Country'] = energy['Country'].str.replace(r"\(.*\)","").str.strip()

    # Renaming Counties
    rename_country = {"Republic of Korea": "South Korea",
    "United States of America": "United States",
    "United Kingdom of Great Britain and Northern Ireland": "United Kingdom",
    "China, Hong Kong Special Administrative Region": "Hong Kong"}


    for key, country in energy['Country'].items():
        if country in rename_country.keys():
            energy['Country'][key] = rename_country[country]

    # Loading GDP data
    GDP = pd.read_csv('world_bank.csv', header = None, skiprows = 4)
    GDP.iloc[0] = GDP.iloc[0].astype(str).str.replace(r"\.0*","")
    GDP.columns = GDP.iloc[0]
    GDP.drop(GDP.index[0]).reset_index().drop('index',1)

    # Renaming Countries
    rc = { "Korea, Rep.": "South Korea", 
    "Iran, Islamic Rep.": "Iran",
    "Hong Kong SAR, China": "Hong Kong"
    }

    for key, country in GDP['Country Name'].items():
        if country in rc.keys():
            GDP['Country Name'][key] = rc[country]

    # Load Country Rank Data For Energy
    ScimEn = pd.read_excel('scimagojr-3.xlsx')

    # Merging Data
    GDP_10_years = GDP[['Country Name','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015']]

    merged = pd.merge(ScimEn, energy, how = "inner", left_on = 'Country', right_on = 'Country')
    merged = pd.merge(merged, GDP_10_years, how = "inner", left_on = 'Country', right_on = 'Country Name')
    merged.set_index('Country', inplace = True)
    merged = merged.drop('Country Name', 1)
    merged_top_15 = merged[:15]
    return merged_top_15

answer_one()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy





<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Documents</th>
      <th>Citable documents</th>
      <th>Citations</th>
      <th>Self-citations</th>
      <th>Citations per document</th>
      <th>H index</th>
      <th>Energy Supply</th>
      <th>Energy Supply per Capita</th>
      <th>% Renewable</th>
      <th>2006</th>
      <th>2007</th>
      <th>2008</th>
      <th>2009</th>
      <th>2010</th>
      <th>2011</th>
      <th>2012</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
    </tr>
    <tr>
      <th>Country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>China</th>
      <td>1</td>
      <td>127050</td>
      <td>126767</td>
      <td>597237</td>
      <td>411683</td>
      <td>4.70</td>
      <td>138</td>
      <td>1.271910e+11</td>
      <td>93.0</td>
      <td>19.754910</td>
      <td>3.99233e+12</td>
      <td>4.55904e+12</td>
      <td>4.99778e+12</td>
      <td>5.45925e+12</td>
      <td>6.03966e+12</td>
      <td>6.61249e+12</td>
      <td>7.12498e+12</td>
      <td>7.67245e+12</td>
      <td>8.23012e+12</td>
      <td>8.798e+12</td>
    </tr>
    <tr>
      <th>United States</th>
      <td>2</td>
      <td>96661</td>
      <td>94747</td>
      <td>792274</td>
      <td>265436</td>
      <td>8.20</td>
      <td>230</td>
      <td>9.083800e+10</td>
      <td>286.0</td>
      <td>11.570980</td>
      <td>1.47923e+13</td>
      <td>1.50554e+13</td>
      <td>1.50115e+13</td>
      <td>1.45948e+13</td>
      <td>1.49644e+13</td>
      <td>1.5204e+13</td>
      <td>1.55422e+13</td>
      <td>1.57737e+13</td>
      <td>1.61566e+13</td>
      <td>1.65486e+13</td>
    </tr>
    <tr>
      <th>Japan</th>
      <td>3</td>
      <td>30504</td>
      <td>30287</td>
      <td>223024</td>
      <td>61554</td>
      <td>7.31</td>
      <td>134</td>
      <td>1.898400e+10</td>
      <td>149.0</td>
      <td>10.232820</td>
      <td>5.49654e+12</td>
      <td>5.61704e+12</td>
      <td>5.55853e+12</td>
      <td>5.25131e+12</td>
      <td>5.49872e+12</td>
      <td>5.47374e+12</td>
      <td>5.5691e+12</td>
      <td>5.64466e+12</td>
      <td>5.64288e+12</td>
      <td>5.66956e+12</td>
    </tr>
    <tr>
      <th>United Kingdom</th>
      <td>4</td>
      <td>20944</td>
      <td>20357</td>
      <td>206091</td>
      <td>37874</td>
      <td>9.84</td>
      <td>139</td>
      <td>7.920000e+09</td>
      <td>124.0</td>
      <td>10.600470</td>
      <td>2.41963e+12</td>
      <td>2.4822e+12</td>
      <td>2.47061e+12</td>
      <td>2.36705e+12</td>
      <td>2.4035e+12</td>
      <td>2.45091e+12</td>
      <td>2.47981e+12</td>
      <td>2.53337e+12</td>
      <td>2.60564e+12</td>
      <td>2.66633e+12</td>
    </tr>
    <tr>
      <th>Russian Federation</th>
      <td>5</td>
      <td>18534</td>
      <td>18301</td>
      <td>34266</td>
      <td>12422</td>
      <td>1.85</td>
      <td>57</td>
      <td>3.070900e+10</td>
      <td>214.0</td>
      <td>17.288680</td>
      <td>1.38579e+12</td>
      <td>1.50407e+12</td>
      <td>1.583e+12</td>
      <td>1.4592e+12</td>
      <td>1.52492e+12</td>
      <td>1.58994e+12</td>
      <td>1.64588e+12</td>
      <td>1.66693e+12</td>
      <td>1.67871e+12</td>
      <td>1.61615e+12</td>
    </tr>
    <tr>
      <th>Canada</th>
      <td>6</td>
      <td>17899</td>
      <td>17620</td>
      <td>215003</td>
      <td>40930</td>
      <td>12.01</td>
      <td>149</td>
      <td>1.043100e+10</td>
      <td>296.0</td>
      <td>61.945430</td>
      <td>1.56447e+12</td>
      <td>1.59674e+12</td>
      <td>1.61271e+12</td>
      <td>1.56514e+12</td>
      <td>1.61341e+12</td>
      <td>1.66409e+12</td>
      <td>1.69313e+12</td>
      <td>1.73069e+12</td>
      <td>1.77349e+12</td>
      <td>1.79261e+12</td>
    </tr>
    <tr>
      <th>Germany</th>
      <td>7</td>
      <td>17027</td>
      <td>16831</td>
      <td>140566</td>
      <td>27426</td>
      <td>8.26</td>
      <td>126</td>
      <td>1.326100e+10</td>
      <td>165.0</td>
      <td>17.901530</td>
      <td>3.33289e+12</td>
      <td>3.44156e+12</td>
      <td>3.47881e+12</td>
      <td>3.28334e+12</td>
      <td>3.4173e+12</td>
      <td>3.54237e+12</td>
      <td>3.55672e+12</td>
      <td>3.56732e+12</td>
      <td>3.62439e+12</td>
      <td>3.68556e+12</td>
    </tr>
    <tr>
      <th>India</th>
      <td>8</td>
      <td>15005</td>
      <td>14841</td>
      <td>128763</td>
      <td>37209</td>
      <td>8.58</td>
      <td>115</td>
      <td>3.319500e+10</td>
      <td>26.0</td>
      <td>14.969080</td>
      <td>1.26589e+12</td>
      <td>1.37487e+12</td>
      <td>1.42836e+12</td>
      <td>1.54948e+12</td>
      <td>1.70846e+12</td>
      <td>1.82187e+12</td>
      <td>1.92424e+12</td>
      <td>2.05198e+12</td>
      <td>2.20062e+12</td>
      <td>2.36721e+12</td>
    </tr>
    <tr>
      <th>France</th>
      <td>9</td>
      <td>13153</td>
      <td>12973</td>
      <td>130632</td>
      <td>28601</td>
      <td>9.93</td>
      <td>114</td>
      <td>1.059700e+10</td>
      <td>166.0</td>
      <td>17.020280</td>
      <td>2.60784e+12</td>
      <td>2.66942e+12</td>
      <td>2.67464e+12</td>
      <td>2.59597e+12</td>
      <td>2.64699e+12</td>
      <td>2.70203e+12</td>
      <td>2.70697e+12</td>
      <td>2.72257e+12</td>
      <td>2.72963e+12</td>
      <td>2.76119e+12</td>
    </tr>
    <tr>
      <th>South Korea</th>
      <td>10</td>
      <td>11983</td>
      <td>11923</td>
      <td>114675</td>
      <td>22595</td>
      <td>9.57</td>
      <td>104</td>
      <td>1.100700e+10</td>
      <td>221.0</td>
      <td>2.279353</td>
      <td>9.4102e+11</td>
      <td>9.92432e+11</td>
      <td>1.02051e+12</td>
      <td>1.02773e+12</td>
      <td>1.0945e+12</td>
      <td>1.1348e+12</td>
      <td>1.16081e+12</td>
      <td>1.19443e+12</td>
      <td>1.23434e+12</td>
      <td>1.26658e+12</td>
    </tr>
    <tr>
      <th>Italy</th>
      <td>11</td>
      <td>10964</td>
      <td>10794</td>
      <td>111850</td>
      <td>26661</td>
      <td>10.20</td>
      <td>106</td>
      <td>6.530000e+09</td>
      <td>109.0</td>
      <td>33.667230</td>
      <td>2.20217e+12</td>
      <td>2.23463e+12</td>
      <td>2.21115e+12</td>
      <td>2.08994e+12</td>
      <td>2.12518e+12</td>
      <td>2.13744e+12</td>
      <td>2.07718e+12</td>
      <td>2.04087e+12</td>
      <td>2.03387e+12</td>
      <td>2.04932e+12</td>
    </tr>
    <tr>
      <th>Spain</th>
      <td>12</td>
      <td>9428</td>
      <td>9330</td>
      <td>123336</td>
      <td>23964</td>
      <td>13.08</td>
      <td>115</td>
      <td>4.923000e+09</td>
      <td>106.0</td>
      <td>37.968590</td>
      <td>1.41482e+12</td>
      <td>1.46815e+12</td>
      <td>1.48453e+12</td>
      <td>1.43148e+12</td>
      <td>1.43167e+12</td>
      <td>1.41735e+12</td>
      <td>1.38022e+12</td>
      <td>1.35714e+12</td>
      <td>1.37561e+12</td>
      <td>1.41982e+12</td>
    </tr>
    <tr>
      <th>Iran</th>
      <td>13</td>
      <td>8896</td>
      <td>8819</td>
      <td>57470</td>
      <td>19125</td>
      <td>6.46</td>
      <td>72</td>
      <td>9.172000e+09</td>
      <td>119.0</td>
      <td>5.707721</td>
      <td>3.89552e+11</td>
      <td>4.25065e+11</td>
      <td>4.28991e+11</td>
      <td>4.38921e+11</td>
      <td>4.6779e+11</td>
      <td>4.85331e+11</td>
      <td>4.53257e+11</td>
      <td>4.44593e+11</td>
      <td>4.63903e+11</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Australia</th>
      <td>14</td>
      <td>8831</td>
      <td>8725</td>
      <td>90765</td>
      <td>15606</td>
      <td>10.28</td>
      <td>107</td>
      <td>5.386000e+09</td>
      <td>231.0</td>
      <td>11.810810</td>
      <td>1.02194e+12</td>
      <td>1.06034e+12</td>
      <td>1.09964e+12</td>
      <td>1.11965e+12</td>
      <td>1.14225e+12</td>
      <td>1.16943e+12</td>
      <td>1.21191e+12</td>
      <td>1.24148e+12</td>
      <td>1.27252e+12</td>
      <td>1.30125e+12</td>
    </tr>
    <tr>
      <th>Brazil</th>
      <td>15</td>
      <td>8668</td>
      <td>8596</td>
      <td>60702</td>
      <td>14396</td>
      <td>7.00</td>
      <td>86</td>
      <td>1.214900e+10</td>
      <td>59.0</td>
      <td>69.648030</td>
      <td>1.84508e+12</td>
      <td>1.95712e+12</td>
      <td>2.05681e+12</td>
      <td>2.05421e+12</td>
      <td>2.20887e+12</td>
      <td>2.29524e+12</td>
      <td>2.33921e+12</td>
      <td>2.40974e+12</td>
      <td>2.41223e+12</td>
      <td>2.31942e+12</td>
    </tr>
  </tbody>
</table>
</div>



### Question 2 (6.6%)
The previous question joined three datasets then reduced this to just the top 15 entries. When you joined the datasets, but before you reduced this to the top 15 items, how many entries did you lose?

*This function should return a single number.*


```python
%%HTML
<svg width="800" height="300">
  <circle cx="150" cy="180" r="80" fill-opacity="0.2" stroke="black" stroke-width="2" fill="blue" />
  <circle cx="200" cy="100" r="80" fill-opacity="0.2" stroke="black" stroke-width="2" fill="red" />
  <circle cx="100" cy="100" r="80" fill-opacity="0.2" stroke="black" stroke-width="2" fill="green" />
  <line x1="150" y1="125" x2="300" y2="150" stroke="black" stroke-width="2" fill="black" stroke-dasharray="5,3"/>
  <text  x="300" y="165" font-family="Verdana" font-size="35">Everything but this!</text>
</svg>
```


<svg width="800" height="300">
  <circle cx="150" cy="180" r="80" fill-opacity="0.2" stroke="black" stroke-width="2" fill="blue" />
  <circle cx="200" cy="100" r="80" fill-opacity="0.2" stroke="black" stroke-width="2" fill="red" />
  <circle cx="100" cy="100" r="80" fill-opacity="0.2" stroke="black" stroke-width="2" fill="green" />
  <line x1="150" y1="125" x2="300" y2="150" stroke="black" stroke-width="2" fill="black" stroke-dasharray="5,3"/>
  <text  x="300" y="165" font-family="Verdana" font-size="35">Everything but this!</text>
</svg>



```python
def answer_two():
    import pandas as pd
    import numpy as np
    energy = pd.read_excel('Energy Indicators.xls',
                           header = None, 
                           usecols=range(2,6),
                           names = ['Country', 'Energy Supply', 'Energy Supply per Capita', '% Renewable'])
    energy = energy[18:245]

    # replacing missing values
    energy.replace(to_replace = '...', value = np.NaN, inplace = True)

    # converting to gigajoules
    energy['Energy Supply'] = energy['Energy Supply']*1000000

    # Removing Numbered Countries
    energy['Country'] = energy['Country'].str.replace('\d+', '')

    # Removing Countries with Parenthises in name
    energy['Country'] = energy['Country'].str.replace(r"\(.*\)","").str.strip()

    # Renaming Counties
    rename_country = {"Republic of Korea": "South Korea",
    "United States of America": "United States",
    "United Kingdom of Great Britain and Northern Ireland": "United Kingdom",
    "China, Hong Kong Special Administrative Region": "Hong Kong"}


    for key, country in energy['Country'].items():
        if country in rename_country.keys():
            energy['Country'][key] = rename_country[country]

    # Loading GDP data
    GDP = pd.read_csv('world_bank.csv', header = None, skiprows = 4)
    GDP.iloc[0] = GDP.iloc[0].astype(str).str.replace(r"\.0*","")
    GDP.columns = GDP.iloc[0]
    GDP.drop(GDP.index[0]).reset_index().drop('index',1)

    # Renaming Countries
    rc = { "Korea, Rep.": "South Korea", 
    "Iran, Islamic Rep.": "Iran",
    "Hong Kong SAR, China": "Hong Kong"
    }

    for key, country in GDP['Country Name'].items():
        if country in rc.keys():
            GDP['Country Name'][key] = rc[country]

    # Load Country Rank Data For Energy
    ScimEn = pd.read_excel('scimagojr-3.xlsx')

    # Merging Data
    GDP_10_years = GDP[['Country Name','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015']]

    merged = pd.merge(ScimEn, energy, how = "inner", left_on = 'Country', right_on = 'Country')
    merged_2 = pd.merge(merged, GDP_10_years, how = "inner", left_on = 'Country', right_on = 'Country Name')
    merged.set_index('Country', inplace = True)
    merged = merged.drop('Country Name', 1)
    merged_top_15 = merged[:15]
    
    return len(merged.index) - len(merged_top_15.index)

answer_two()
     
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy



    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-166-0a13bd61ad21> in <module>()
         61     return len(merged.index) - len(merged_top_15.index)
         62 
    ---> 63 answer_two()
         64 


    <ipython-input-166-0a13bd61ad21> in answer_two()
         56     merged_2 = pd.merge(merged, GDP_10_years, how = "inner", left_on = 'Country', right_on = 'Country Name')
         57     merged.set_index('Country', inplace = True)
    ---> 58     merged = merged.drop('Country Name', 1)
         59     merged_top_15 = merged[:15]
         60 


    /opt/conda/lib/python3.5/site-packages/pandas/core/generic.py in drop(self, labels, axis, level, inplace, errors)
       1875                 new_axis = axis.drop(labels, level=level, errors=errors)
       1876             else:
    -> 1877                 new_axis = axis.drop(labels, errors=errors)
       1878             dropped = self.reindex(**{axis_name: new_axis})
       1879             try:


    /opt/conda/lib/python3.5/site-packages/pandas/indexes/base.py in drop(self, labels, errors)
       3049             if errors != 'ignore':
       3050                 raise ValueError('labels %s not contained in axis' %
    -> 3051                                  labels[mask])
       3052             indexer = indexer[~mask]
       3053         return self.delete(indexer)


    ValueError: labels ['Country Name'] not contained in axis


<br>

Answer the following questions in the context of only the top 15 countries by Scimagojr Rank (aka the DataFrame returned by `answer_one()`)

### Question 3 (6.6%)
What is the average GDP over the last 10 years for each country? (exclude missing values from this calculation.)

*This function should return a Series named `avgGDP` with 15 countries and their average GDP sorted in descending order.*


```python
def answer_three():
    import pandas as pd
    
    Top15 = answer_one()
    Top15_GDP = Top15[['2006','2007','2008','2009','2010','2011','2012','2013','2014','2015']]
    avgGDP = pd.Series(Top15_GDP.mean(axis = 1).sort_values(ascending = False))
    
    return avgGDP

answer_three() 
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy





    Country
    United States         1.536434e+13
    China                 6.348609e+12
    Japan                 5.542208e+12
    Germany               3.493025e+12
    France                2.681725e+12
    United Kingdom        2.487907e+12
    Brazil                2.189794e+12
    Italy                 2.120175e+12
    India                 1.769297e+12
    Canada                1.660647e+12
    Russian Federation    1.565459e+12
    Spain                 1.418078e+12
    Australia             1.164043e+12
    South Korea           1.106715e+12
    Iran                  4.441558e+11
    dtype: float64



### Question 4 (6.6%)
By how much had the GDP changed over the 10 year span for the country with the 6th largest average GDP?

*This function should return a single number.*


```python
def answer_four():
    import pandas as pd
    import numpy
    
    Top15 = answer_one()
    avgGDP = answer_three()
    sixth_largest_GDP = avgGDP.nlargest(6).tail(1).index
    change = (Top15['2015'][sixth_largest_GDP] - Top15['2006'][sixth_largest_GDP])[0]
    return numpy.float64(change)

answer_four()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy





    246702696075.3999



### Question 5 (6.6%)
What is the mean `Energy Supply per Capita`?

*This function should return a single number.*


```python
def answer_five():
    Top15 = answer_one()
    return Top15['Energy Supply per Capita'].mean()

answer_five()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy





    157.59999999999999



### Question 6 (6.6%)
What country has the maximum % Renewable and what is the percentage?

*This function should return a tuple with the name of the country and the percentage.*


```python
def answer_six():
    Top15 = answer_one()
    return (Top15['% Renewable'].argmax(), Top15['% Renewable'].max())

answer_six()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy





    ('Brazil', 69.648030000000006)



### Question 7 (6.6%)
Create a new column that is the ratio of Self-Citations to Total Citations. 
What is the maximum value for this new column, and what country has the highest ratio?

*This function should return a tuple with the name of the country and the ratio.*


```python
def answer_seven():
    Top15 = answer_one()
    Top15['SC_to_TC'] = Top15['Self-citations']/Top15['Citations']
    return (Top15['SC_to_TC'].argmax(), Top15['SC_to_TC'].max())

answer_seven()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy





    ('China', 0.68931261793894216)



### Question 8 (6.6%)

Create a column that estimates the population using Energy Supply and Energy Supply per capita. 
What is the third most populous country according to this estimate?

*This function should return a single string value.*


```python
def answer_eight():
    Top15 = answer_one()
    Top15['PopEst'] = Top15['Energy Supply'] / Top15['Energy Supply per Capita']
    return Top15['PopEst'].nlargest(3).argmin()

answer_eight()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy





    'United States'



### Question 9 (6.6%)
Create a column that estimates the number of citable documents per person. 
What is the correlation between the number of citable documents per capita and the energy supply per capita? Use the `.corr()` method, (Pearson's correlation).

*This function should return a single number.*

*(Optional: Use the built-in function `plot9()` to visualize the relationship between Energy Supply per Capita vs. Citable docs per Capita)*


```python
def answer_nine():
    Top15 = answer_one()
    Top15['PopEst'] = Top15['Energy Supply'] / Top15['Energy Supply per Capita']
    Top15['Citable docs per Capita'] = Top15['Citable documents'] / Top15['PopEst'] 
    corr_matrix = Top15.corr(method='pearson')
    return corr_matrix['Citable docs per Capita']['Energy Supply per Capita']

answer_nine()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy





    0.79400104354429435




```python
def plot9():
    import matplotlib as plt
    %matplotlib inline
    
    Top15 = answer_one()
    Top15['PopEst'] = Top15['Energy Supply'] / Top15['Energy Supply per Capita']
    Top15['Citable docs per Capita'] = Top15['Citable documents'] / Top15['PopEst']
    Top15.plot(x='Citable docs per Capita', y='Energy Supply per Capita', kind='scatter', xlim=[0, 0.0006])
```

    /opt/conda/lib/python3.5/site-packages/matplotlib/font_manager.py:273: UserWarning: Matplotlib is building the font cache using fc-list. This may take a moment.
      warnings.warn('Matplotlib is building the font cache using fc-list. This may take a moment.')
    /opt/conda/lib/python3.5/site-packages/matplotlib/font_manager.py:273: UserWarning: Matplotlib is building the font cache using fc-list. This may take a moment.
      warnings.warn('Matplotlib is building the font cache using fc-list. This may take a moment.')
    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy



![png](output_22_1.png)



```python
#plot9() # Be sure to comment out plot9() before submitting the assignment!
```

### Question 10 (6.6%)
Create a new column with a 1 if the country's % Renewable value is at or above the median for all countries in the top 15, and a 0 if the country's % Renewable value is below the median.

*This function should return a series named `HighRenew` whose index is the country name sorted in ascending order of rank.*


```python
def answer_ten():
    Top15 = answer_one()
    MedRenew = Top15['% Renewable'].median()
    Top15['HighRenew'] = Top15['% Renewable'] >= MedRenew
    return Top15['HighRenew']*1

answer_ten()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy





    Country
    China                 1
    United States         0
    Japan                 0
    United Kingdom        0
    Russian Federation    1
    Canada                1
    Germany               1
    India                 0
    France                1
    South Korea           0
    Italy                 1
    Spain                 1
    Iran                  0
    Australia             0
    Brazil                1
    Name: HighRenew, dtype: int64



### Question 11 (6.6%)
Use the following dictionary to group the Countries by Continent, then create a dateframe that displays the sample size (the number of countries in each continent bin), and the sum, mean, and std deviation for the estimated population of each country.

```python
ContinentDict  = {'China':'Asia', 
                  'United States':'North America', 
                  'Japan':'Asia', 
                  'United Kingdom':'Europe', 
                  'Russian Federation':'Europe', 
                  'Canada':'North America', 
                  'Germany':'Europe', 
                  'India':'Asia',
                  'France':'Europe', 
                  'South Korea':'Asia', 
                  'Italy':'Europe', 
                  'Spain':'Europe', 
                  'Iran':'Asia',
                  'Australia':'Australia', 
                  'Brazil':'South America'}
```

*This function should return a DataFrame with index named Continent `['Asia', 'Australia', 'Europe', 'North America', 'South America']` and columns `['size', 'sum', 'mean', 'std']`*


```python
def answer_eleven():
    
    import numpy as np
    
    Top15 = answer_one()
    ContinentDict  = {'China':'Asia', 
                  'United States':'North America', 
                  'Japan':'Asia', 
                  'United Kingdom':'Europe', 
                  'Russian Federation':'Europe', 
                  'Canada':'North America', 
                  'Germany':'Europe', 
                  'India':'Asia',
                  'France':'Europe', 
                  'South Korea':'Asia', 
                  'Italy':'Europe', 
                  'Spain':'Europe', 
                  'Iran':'Asia',
                  'Australia':'Australia', 
                  'Brazil':'South America'}
    
    # Creating Continent Column and Assigning values from the dict
    Top15['Continent'] = 1
    for country in Top15.index:
        if country in ContinentDict:
            Top15['Continent'][country] = ContinentDict[country]
            
    # Population Estimate
    Top15['PopEst'] = Top15['Energy Supply'] / Top15['Energy Supply per Capita']
    
    # Aggregating and Creatitng a data frame
    aggdf = Top15.groupby('Continent').agg({'PopEst': (len, sum, np.mean, np.std)})
    aggdf.columns = ['size', 'sum', 'mean', 'std']
    return aggdf 
    
answer_eleven()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:26: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /opt/conda/lib/python3.5/site-packages/pandas/core/indexing.py:132: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      self._setitem_with_indexer(indexer, value)





<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>size</th>
      <th>sum</th>
      <th>mean</th>
      <th>std</th>
    </tr>
    <tr>
      <th>Continent</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Asia</th>
      <td>5.0</td>
      <td>2.898666e+09</td>
      <td>5.797333e+08</td>
      <td>6.790979e+08</td>
    </tr>
    <tr>
      <th>Australia</th>
      <td>1.0</td>
      <td>2.331602e+07</td>
      <td>2.331602e+07</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Europe</th>
      <td>6.0</td>
      <td>4.579297e+08</td>
      <td>7.632161e+07</td>
      <td>3.464767e+07</td>
    </tr>
    <tr>
      <th>North America</th>
      <td>2.0</td>
      <td>3.528552e+08</td>
      <td>1.764276e+08</td>
      <td>1.996696e+08</td>
    </tr>
    <tr>
      <th>South America</th>
      <td>1.0</td>
      <td>2.059153e+08</td>
      <td>2.059153e+08</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



### Question 12 (6.6%)
Cut % Renewable into 5 bins. Group Top15 by the Continent, as well as these new % Renewable bins. How many countries are in each of these groups?

*This function should return a __Series__ with a MultiIndex of `Continent`, then the bins for `% Renewable`. Do not include groups with no countries.*


```python
def answer_twelve():
    import pandas as pd
    Top15 = answer_one()
    
    ContinentDict  = {'China':'Asia', 
                  'United States':'North America', 
                  'Japan':'Asia', 
                  'United Kingdom':'Europe', 
                  'Russian Federation':'Europe', 
                  'Canada':'North America', 
                  'Germany':'Europe', 
                  'India':'Asia',
                  'France':'Europe', 
                  'South Korea':'Asia', 
                  'Italy':'Europe', 
                  'Spain':'Europe', 
                  'Iran':'Asia',
                  'Australia':'Australia', 
                  'Brazil':'South America'}
    
    # Creating Continent Column and Assigning values from the dict
    Top15['Continent'] = 1
    for country in Top15.index:
        if country in ContinentDict:
            Top15['Continent'][country] = ContinentDict[country]
    
    Top15['RenewBin'] = pd.cut(Top15['% Renewable'], 5)
    grouped = Top15.groupby(['Continent','RenewBin']).agg({'RenewBin':len})
    grouped.columns = ['Number of Countries']
    return grouped['Number of Countries']

answer_twelve()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:25: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /opt/conda/lib/python3.5/site-packages/pandas/core/indexing.py:132: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      self._setitem_with_indexer(indexer, value)





    Continent      RenewBin        
    Asia           (2.212, 15.753]     4
                   (15.753, 29.227]    1
    Australia      (2.212, 15.753]     1
    Europe         (2.212, 15.753]     1
                   (15.753, 29.227]    3
                   (29.227, 42.701]    2
    North America  (2.212, 15.753]     1
                   (56.174, 69.648]    1
    South America  (56.174, 69.648]    1
    Name: Number of Countries, dtype: int64



### Question 13 (6.6%)
Convert the Population Estimate series to a string with thousands separator (using commas). Do not round the results.

e.g. 317615384.61538464 -> 317,615,384.61538464

*This function should return a Series `PopEst` whose index is the country name and whose values are the population estimate string.*


```python
def answer_thirteen():
    Top15 = answer_one()
    
    # Population Estimate
    Top15['PopEst'] = Top15['Energy Supply'] / Top15['Energy Supply per Capita']
    for key, value in Top15['PopEst'].items():
        Top15['PopEst'][key] = '{:,}'.format(value)
        
    return Top15['PopEst']

answer_thirteen()
```

    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:31: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /opt/conda/lib/python3.5/site-packages/ipykernel/__main__.py:6: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
    /opt/conda/lib/python3.5/site-packages/pandas/core/indexing.py:132: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: http://pandas.pydata.org/pandas-docs/stable/indexing.html#indexing-view-versus-copy
      self._setitem_with_indexer(indexer, value)





    Country
    China                 1,367,645,161.2903225
    United States          317,615,384.61538464
    Japan                  127,409,395.97315437
    United Kingdom         63,870,967.741935484
    Russian Federation            143,500,000.0
    Canada                  35,239,864.86486486
    Germany                 80,369,696.96969697
    India                 1,276,730,769.2307692
    France                  63,837,349.39759036
    South Korea            49,805,429.864253394
    Italy                  59,908,256.880733944
    Spain                    46,443,396.2264151
    Iran                    77,075,630.25210084
    Australia              23,316,017.316017315
    Brazil                 205,915,254.23728815
    Name: PopEst, dtype: object



### Optional

Use the built in function `plot_optional()` to see an example visualization.


```python
def plot_optional():
    import matplotlib as plt
    %matplotlib inline
    Top15 = answer_one()
    ax = Top15.plot(x='Rank', y='% Renewable', kind='scatter', 
                    c=['#e41a1c','#377eb8','#e41a1c','#4daf4a','#4daf4a','#377eb8','#4daf4a','#e41a1c',
                       '#4daf4a','#e41a1c','#4daf4a','#4daf4a','#e41a1c','#dede00','#ff7f00'], 
                    xticks=range(1,16), s=6*Top15['2014']/10**10, alpha=.75, figsize=[16,6]);

    for i, txt in enumerate(Top15.index):
        ax.annotate(txt, [Top15['Rank'][i], Top15['% Renewable'][i]], ha='center')

    print("This is an example of a visualization that can be created to help understand the data. \
This is a bubble chart showing % Renewable vs. Rank. The size of the bubble corresponds to the countries' \
2014 GDP, and the color corresponds to the continent.")
```


```python
#plot_optional() # Be sure to comment out plot_optional() before submitting the assignment!
```
